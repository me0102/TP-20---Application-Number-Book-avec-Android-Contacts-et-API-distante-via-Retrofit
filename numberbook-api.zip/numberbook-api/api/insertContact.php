<?php
// CRITICAL RULE: No HTML errors, always strictly valid JSON
error_reporting(0);
header("Content-Type: application/json; charset=UTF-8");
require_once __DIR__ . '/../service/ContactService.php';

try {
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        $data = json_decode(file_get_contents("php://input"), true);

        if (!isset($data['name']) || !isset($data['phone'])) {
            echo json_encode([
                "success" => false,
                "message" => "Champs manquants"
            ]);
            exit;
        }

        $service = new ContactService();
        $ok = $service->insert($data['name'], $data['phone'], "mobile");

        echo json_encode([
            "success" => $ok,
            "message" => $ok ? "Contact inséré avec succès" : "Erreur d'insertion"
        ]);
    } else {
        echo json_encode([
            "success" => false, 
            "message" => "Méthode non autorisée"
        ]);
    }
} catch (Exception $e) {
    // Return a safe JSON error response to prevent Android parsing crash
    echo json_encode([
        "success" => false, 
        "message" => "Erreur serveur"
    ]);
}
?>