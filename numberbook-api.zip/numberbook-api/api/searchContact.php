<?php
// CRITICAL RULE: No HTML errors, always strictly valid JSON
error_reporting(0);
header("Content-Type: application/json; charset=UTF-8");
require_once __DIR__ . '/../service/ContactService.php';

try {
    if (!isset($_GET['keyword'])) {
        echo json_encode([]);
        exit;
    }

    $keyword = trim($_GET['keyword']);
    if (empty($keyword)) {
        echo json_encode([]);
        exit;
    }

    $service = new ContactService();
    $result = $service->search($keyword);

    echo json_encode($result);
} catch (Exception $e) {
    // Return an empty JSON array to prevent Android crash
    echo json_encode([]);
}
?>