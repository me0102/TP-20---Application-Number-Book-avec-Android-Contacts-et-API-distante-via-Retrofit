<?php
// CRITICAL RULE: No HTML errors, always strictly valid JSON
error_reporting(0);
header("Content-Type: application/json; charset=UTF-8");
require_once __DIR__ . '/../service/ContactService.php';

try {
    $service = new ContactService();
    $result = $service->getAll();

    echo json_encode($result);
} catch (Exception $e) {
    // Return an empty JSON array so Android lists just stay empty instead of crashing
    echo json_encode([]);
}
?>