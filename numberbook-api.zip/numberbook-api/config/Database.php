<?php
// CRITICAL RULE: Disable HTML/text error reporting so we never break the JSON structure
error_reporting(0);

class Database {
    private $host = "localhost";
    private $dbName = "numberbook";
    private $username = "root";
    private $password = "";
    public $conn;

    public function getConnection() {
        $this->conn = null;

        try {
            $this->conn = new PDO(
                "mysql:host=" . $this->host . ";dbname=" . $this->dbName . ";charset=utf8mb4",
                $this->username,
                $this->password
            );
            $this->conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        } catch (PDOException $exception) {
            // CRITICAL RULE: Always return valid JSON on failure to prevent Volley ClassCast/Parsing crashes
            echo json_encode([
                "success" => false,
                "message" => "Erreur de connexion : " . $exception->getMessage()
            ]);
            exit; // Stop execution immediately
        }

        return $this->conn;
    }
}
?>