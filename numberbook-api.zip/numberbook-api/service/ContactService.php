<?php
require_once __DIR__ . '/../config/Database.php';

class ContactService {
    private $conn;
    // CRITICAL RULE: Table name wrapped in backticks later in the query
    private $table = "contact";

    public function __construct() {
        $database = new Database();
        $this->conn = $database->getConnection();
    }

    public function insert($name, $phone, $source = "mobile") {
        try {
            // CRITICAL RULE: Backticks around table and all column names
            $sql = "INSERT INTO `" . $this->table . "` (`name`, `phone`, `source`)
                    VALUES (:name, :phone, :source)";
            $stmt = $this->conn->prepare($sql);
            return $stmt->execute([
                ':name' => $name,
                ':phone' => $phone,
                ':source' => $source
            ]);
        } catch (PDOException $e) {
            // Catching the error to prevent PHP from outputting HTML error stacks
            return false;
        }
    }

    public function getAll() {
        try {
            // CRITICAL RULE: Backticks used here as well
            $sql = "SELECT * FROM `" . $this->table . "` ORDER BY `name` ASC";
            $stmt = $this->conn->prepare($sql);
            $stmt->execute();
            return $stmt->fetchAll(PDO::FETCH_ASSOC);
        } catch (PDOException $e) {
            return [];
        }
    }

    public function search($keyword) {
        try {
            // CRITICAL RULE: Backticks applied
            $sql = "SELECT * FROM `" . $this->table . "`
                    WHERE `name` LIKE :keyword OR `phone` LIKE :keyword
                    ORDER BY `name` ASC";
            $stmt = $this->conn->prepare($sql);
            $stmt->execute([
                ':keyword' => '%' . $keyword . '%'
            ]);
            return $stmt->fetchAll(PDO::FETCH_ASSOC);
        } catch (PDOException $e) {
            return [];
        }
    }
}
?>